#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl32ext/types.h>
#include <glbinding/gl32ext/boolean.h>
#include <glbinding/gl32ext/values.h>
#include <glbinding/gl32ext/bitfield.h>
#include <glbinding/gl32ext/enum.h>
#include <glbinding/gl32ext/functions.h>
