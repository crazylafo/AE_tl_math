#pragma once

#include <glbinding/nogl.h>
#include <glbinding/gl/values.h>


namespace gl32ext
{




} // namespace gl32ext
