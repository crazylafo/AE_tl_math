#pragma once

namespace 
{
	const unsigned int GL_REVISION = 31811;
}
